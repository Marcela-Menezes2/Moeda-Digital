//
//  FavoritsCollectionViewController.swift
//  Moeda Digital
//
//  Created by Marcela Menezes Silva on 11/03/22.
//

import UIKit

private let reuseIdentifier = "Cell"

class FavoritsCollectionViewController: UICollectionViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
      //  collectionView?.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "id")
        
        
           func loadView() {
            let view = UIView()
            self.view = view
            self.view.backgroundColor = .black
        }
        // Register cell classes
        self.collectionView!.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "id")

    // MARK: UICollectionViewDataSource

        func numberOfSections(in collectionView: UICollectionView) -> Int {
       return 1
    }


        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 5
    }

        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "id", for: indexPath)
        cell.backgroundColor = UIColor(displayP3Red: 141/255, green: 149/255, blue: 98/255, alpha: 1.0)
    
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: 50)
    }
}
}
